/*:

# OHAJIKI

Created By [Riku Arakawa](https://github.com/rikulh)

*/

import PlaygroundSupport
PlaygroundPage.current.setLiveView(MainView())

/*:
 ## Welcome to OHAJIKI!
 “OHAJIKI” is a game with the theme of Ohajiki that is one of the Japanese traditional plays with glass discs.  
Now, let me tell you how to play this game.

 **How to play:**

First, you turn Ohajiki, the glass discs, into your favorite design.  
Choose the pattern and the color of Ohajiki.  
This game has three stages.   

In the stage “Original 1”, you hit the Ohajiki toward a yellow goal.  
Here, you pass Ohajiki between the two which are connected with each other by a line as little moves as possible.  
It influences the number of stars you get.  
If you win four stars, you can raise levels! Let’s achieve three levels in total!  

In the stage “Traditional”, you choose two gray Ohajikis first.  
If you want switch the Ohajiki, deselect and choose again.  
Next, pass your Ohajiki between the two.  
If your Ohajiki goes through hitting neither of two Ohajikis that you chose, you can delete them.  
All you have to do is to repeat this action, and delete the gray Ohajiki.  
Let’s compete how quickly you can get rid of all Ohajikis with me!  

In the stage “Original 2”, you control the Ohajiki which is located by the computer.  
Choose your favorite Ohajiki, and flick it to the other one in the same color.   
Then you can delete the both of the Ohajikis bumping into each other.  
Repeat this, and let’s compete how quickly you can get rid of all Ohajikis with me!  

Now, let’s start this game!  
Choose the stage, read each rule description text, and give it a try!  
*/

/*:
 - Important:
    For a better experience, please disable **Results**.
*/