import SwiftUI
public struct TextureView: View {
    @Binding var state: Window
    let choices: [Color] = [.blue, .red, .green, .yellow, .orange, .pink, .purple]
    let choicesText: [String] = ["Blue", "Red", "Green", "Yellow", "Orange", "Pink", "Purple"]
    @Binding var step: Step
    @State var selection: Int = 0
    @Binding var ohajiki: Ohajiki
    public var body: some View {
        VStack {
            Text("Choose the color")
                .font(.largeTitle)
                .padding(.init(top: 60, leading: 0, bottom: 60, trailing: 0))
            Text(choicesText[selection])
                .font(.largeTitle)
                .animation(nil)
            HStack {
                Button(action: {
                    withAnimation {
                        selection -= 1
                    }
                }){
                    Image(systemName: "chevron.backward.square.fill")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .foregroundColor(.orange)
                        .overlay(
                            Image(uiImage: Color.black.image)
                                .resizable()
                                .frame(width: 60, height: 60)
                                .cornerRadius(7)
                                .opacity(selection == 0 ? 0.6 : 0.0)
                        )
                }
                .disabled(selection == 0)
                VStack {
                    TabView(selection: $selection) {
                        ForEach(0..<choices.count) { i in
                            Image(uiImage: #imageLiteral(resourceName: "ohajikiBack.png").composite(image: ohajiki.inside.image.tint(with: choices[i])!)!.composite(image: #imageLiteral(resourceName: "ohajikiShadow.png"))!.composite(image: #imageLiteral(resourceName: "light.png"))!)
                                .resizable()
                                .id(i)
                                .frame(width: 300, height: 300, alignment: .center)
                        }
                        .padding(.all, 10)
                    }
                    .frame(width: 350, height: 350)
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    .onAppear(perform: {
                        UIScrollView.appearance().bounces = false
                    })
                }
                Button(action: {
                    withAnimation {
                        selection += 1
                    }
                }){
                    Image(systemName: "chevron.forward.square.fill")
                        .resizable()
                        .frame(width: 60, height: 60)
                        .foregroundColor(.orange)
                        .overlay(
                            Image(uiImage: Color.black.image)
                                .resizable()
                                .frame(width: 60, height: 60)
                                .cornerRadius(7)
                                .opacity(selection == choices.count - 1 ? 0.6 : 0.0)
                        )
                }
                .disabled(selection == choices.count - 1)
            }
            HStack(spacing: 20) {
                ForEach(0..<choices.count) { num in
                    Button(action: {
                        withAnimation {
                            selection = num
                        }
                    }){
                        Image(uiImage: #imageLiteral(resourceName: "ohajiki.png").composite(image: ohajiki.inside.image.tint(with: choices[num])!)!.composite(image: #imageLiteral(resourceName: "light.png"))!)
                            .resizable()
                            .frame(width: 25, height: 25)
                    }
                }
            }
            .padding(5)
            Spacer()
            HStack {
                Spacer()
                Button(action: {
                    withAnimation {
                        step = .shape
                    }
                }){
                    Text("←Back")
                        .frame(width: 120)
                        .padding(10)
                        .font(.largeTitle)
                        .foregroundColor(.black)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding(70)
                Spacer()
                Button(action: {
                    ohajiki.color = choices[selection]
                    withAnimation {
                        state = .play
                    }
                }){
                    Text("Next→")
                        .frame(width: 120)
                        .padding(10)
                        .font(.largeTitle)
                        .foregroundColor(.black)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding(70)
                Spacer()
            }
            Spacer()
        }
    }
}
