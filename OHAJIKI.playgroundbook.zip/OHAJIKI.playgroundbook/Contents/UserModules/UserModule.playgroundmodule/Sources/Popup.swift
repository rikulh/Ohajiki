import UIKit
import SpriteKit
import SwiftUI

class CustomDialog : UIView{
    
    var backGroundView : UIView!
    var scene : SKScene!
    var mine: Ohajiki = Ohajiki(color: .blue, inside: .one)
    var level = 1
    init(scene: SKScene, frame: CGRect, moves: Int, coin: Int, life: Int, level: Int, mine: Ohajiki) {
        self.level = level
        super.init(frame: scene.view!.bounds)
        self.scene = scene
        self.mine = mine
        self.scene.view!.isPaused = true
        self.scene.isUserInteractionEnabled = false
        
        
        self.layer.zPosition = 10
        self.backGroundView = UIView(frame: scene.view!.bounds)
        self.backGroundView.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.3)
        self.backGroundView.layer.position = scene.view!.center
        self.addSubview(backGroundView)
        
        
        let board = UIView(frame: frame)
        board.backgroundColor = UIColor.white
        board.layer.position = backGroundView.center
        board.layer.masksToBounds = true
        board.layer.cornerRadius = 10.0
        board.layer.borderColor = UIColor.black.cgColor
        self.addSubview(board)
        
        let textView = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 50))
        
        textView.textAlignment = NSTextAlignment.center
        var stars = 0
        switch (life - moves) {
        case -5, -4:
            stars = 0
        case -3, -2:
            stars = 1
        case -1, 0:
            stars = 2
        case 1, 2:
            stars = 3
        case 3:
            stars = 4
        case 4:
            stars = 5
        default:
            stars = 0
        }
        if level == 1 {
            stars -= 1 - coin
        } else if level == 2 {
            stars -= 1 - coin
        } else if level == 3 {
            stars += coin + 1
        }
        if stars < 0 {
            stars = 0
        } else if stars > 5 {
            stars = 5
        }
        switch stars {
        case 0:
            textView.text = "Good luck!"
        case 1:
            textView.text = "You did!"
        case 2:
            textView.text = "Nice!"
        case 3:
            textView.text = "Great!"
        case 4:
            textView.text = "Excellent!"
        case 5:
            textView.text = "Brilliant!"
        default:
            textView.text = "Good luck!"
        }
        textView.layer.position = CGPoint(x: backGroundView.frame.width / 2, y: 220)
        textView.backgroundColor = UIColor.clear
        textView.textColor = UIColor.black
        textView.font = UIFont(name: "Helvetica", size: 50)
        self.addSubview(textView)
        
        let starView: [UIImageView] = [UIImageView(image: #imageLiteral(resourceName: "star.png")), UIImageView(image: #imageLiteral(resourceName: "star.png")), UIImageView(image: #imageLiteral(resourceName: "star.png")), UIImageView(image: #imageLiteral(resourceName: "star.png")), UIImageView(image: #imageLiteral(resourceName: "star.png"))]
        (0..<stars).forEach { index in 
            print(index)
            starView[index].image = #imageLiteral(resourceName: "star.png").tint(with: .yellow)
        }
        for (i, star) in starView.enumerated() {
            let x: CGFloat = (self.frame.width - 60) / 2
            star.layer.frame = CGRect(x: x + 100 * (CGFloat(i) - 2), y: 400, width: 70, height: 67)
            self.addSubview(star)
        }
        
        let nextButton = UIButton(frame: CGRect(x: backGroundView.frame.width / 2 - 65, y: backGroundView.frame.height - 200, width: 130, height: 60))
        nextButton.tintColor = .black
        nextButton.layer.cornerRadius = 10
        nextButton.setTitleColor(.black, for: .normal)
        nextButton.setBackgroundImage(Color.blue.image, for: .normal)
        nextButton.titleLabel?.textAlignment = .center
        nextButton.layer.masksToBounds = true
        nextButton.setTitle("Next", for: .normal)
        nextButton.titleLabel?.font = UIFont(name: "Helvetica", size: 30)
        
        if stars >= 4 {
            self.addSubview(nextButton)
        }
        if level == 3 {
            nextButton.addTarget(self, action: #selector(self.backSelectButton), for: UIControl.Event.touchUpInside)
            nextButton.setTitle("Select", for: .normal)
        } else {
            nextButton.addTarget(self, action: #selector(self.onNextButton), for: UIControl.Event.touchUpInside)
        }
        
        let finishButton = UIButton(frame: CGRect(x: backGroundView.frame.width / 2 + 100, y: backGroundView.frame.height - 200, width: 130, height: 60))
        finishButton.tintColor = .black
        finishButton.layer.cornerRadius = 10
        finishButton.setTitleColor(.black, for: .normal)
        finishButton.setBackgroundImage(Color.blue.image, for: .normal)
        finishButton.titleLabel?.textAlignment = .center
        finishButton.layer.masksToBounds = true
        finishButton.setTitle("Finish", for: .normal)
        finishButton.titleLabel?.font = UIFont(name: "Helvetica", size: 30)
        
        finishButton.addTarget(self, action: #selector(self.finishButton), for: UIControl.Event.touchUpInside)
        if level == 3 {
            self.addSubview(finishButton)
        }
        
        let replayButton = UIButton(frame: CGRect(x: backGroundView.frame.width / 2 - 230, y: backGroundView.frame.height - 200, width: 130, height: 60))
        replayButton.tintColor = .black
        replayButton.layer.cornerRadius = 10
        replayButton.setTitleColor(.black, for: .normal)
        replayButton.setBackgroundImage(Color.blue.image, for: .normal)
        replayButton.titleLabel?.textAlignment = .center
        replayButton.layer.masksToBounds = true
        replayButton.setTitle("Again", for: .normal)
        replayButton.titleLabel?.font = UIFont(name: "Helvetica", size: 30)
        
        replayButton.addTarget(self, action: #selector(self.onReplayButton), for: UIControl.Event.touchUpInside)
        self.addSubview(replayButton)
        
        if UITraitCollection.isDarkMode {
            textView.textColor = .white
            board.backgroundColor = UIColor(displayP3Red: 0.2, green: 0.2, blue: 0.2, alpha: 1)
        }
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func onNextButton(sender: UIButton) {
        self.scene.view!.isPaused = false
        self.scene.isUserInteractionEnabled = true
        self.removeFromSuperview()
        level += 1
        self.scene.view?.presentScene(PlayScene(screen: backGroundView.frame.size, mine: mine, level: level))
    }
    @objc func finishButton(sender: UIButton) {
        self.scene.view!.isPaused = false
        self.scene.isUserInteractionEnabled = true
        self.removeFromSuperview()
        level += 1
        self.scene.view?.presentScene(PlayScene(screen: backGroundView.frame.size, mine: mine, level: 6))
    }
    @objc func backSelectButton(sender: UIButton) {
        self.scene.view!.isPaused = false
        self.scene.isUserInteractionEnabled = true
        self.removeFromSuperview()
        level += 1
        self.scene.view?.presentScene(ChoseScene(ohaziki: mine, screen: self.scene.size))
    }
    @objc func onReplayButton(sender: UIButton){
        self.scene.view?.isPaused = false
        self.scene.isUserInteractionEnabled = true
        self.removeFromSuperview()
        self.scene.view?.presentScene(PlayScene(screen: backGroundView.frame.size, mine: mine, level: level))
    }
    
}
