import SwiftUI
public struct CustomView: View {
    @Binding var window: Window
    @Environment(\.colorScheme) var colorScheme
    @State var step = Step.shape
    @Binding var ohajiki: Ohajiki
    var topTxtColor: Color {
        switch colorScheme {
        case .dark:
            return Color(red: 0.5, green: 0.5, blue: 0.5)
        case .light:
            return Color(red: 0.8, green: 0.8, blue: 0.8)
        }
    }
    public var body: some View {
        HStack {
            Spacer()
            VStack {
                Text("First, Let's make your own Ohajiki!")
                    .padding(20)
                    .font(.largeTitle)
                    .foregroundColor(.black)
                    .background(self.topTxtColor)
                    .cornerRadius(20)
                    .padding(.init(top: 30, leading: 0, bottom: 0, trailing: 0))
                Spacer()
                switch step {
                case .texture:
                    TextureView(state: $window, step: $step, ohajiki: $ohajiki)
                case .shape:
                    ShapeView(step: $step, ohajiki: $ohajiki, state: $window)  
                }
                
            }
        }
    }
}
