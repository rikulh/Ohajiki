import SwiftUI
import SpriteKit
public struct PlayView: View {
    @State var index = 1
    @Environment(\.colorScheme) public var colorScheme
    @Binding var ohajiki: Ohajiki
    @State var level = 1
    var bgColor: Color {
        switch colorScheme {
        case .dark:
            return Color.black
        case .light:
            return Color.white
        }
    }
    public var body: some View {
        GeometryReader { geometry in
            switch index {
            case 1:
                SpriteView(scene: ChoseScene(ohaziki: ohajiki, screen: geometry.size))
            case 2:
                SpriteView(scene: PlayScene(screen: geometry.size, mine: ohajiki, level: level))
            default:
                MainView()
            }
        }
    }
}
