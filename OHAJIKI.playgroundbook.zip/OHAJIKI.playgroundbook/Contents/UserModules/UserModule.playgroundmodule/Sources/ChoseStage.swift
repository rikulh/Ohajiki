import AVFoundation
import SpriteKit
import SwiftUI
import Foundation

class ChoseScene:SKScene {
    var videoNode = SKVideoNode()
    var screen = CGSize()
    var ohajiki = Ohajiki(color: .blue, inside: .one)
    public init(ohaziki: Ohajiki, screen: CGSize) {
        super.init(size: screen)
        self.screen = screen
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func didMove(to view: SKView) {
        let poss = [CGPoint(x: self.frame.midX - 150, y: self.frame.midY + 200), CGPoint(x: self.frame.midX + 150, y: self.frame.midY + 200), CGPoint(x: self.frame.midX, y: self.frame.midY - 220)]
        let names = ["Traditional", "Original 1", "Original 2"]
        for (i, position) in poss.enumerated() {
            let stage = SKShapeNode(rectOf: CGSize(width: 250, height: 380), cornerRadius: 20)
            stage.position = position
            stage.fillColor = UIColor(displayP3Red: 0.7, green: 0.7, blue: 0.7, alpha: 1)
            stage.lineWidth = 0
            
            videoNode.zPosition = 100
            videoNode = SKVideoNode(avPlayer: self.createPlayer(from: names[i]))
            videoNode.position = position + CGPoint(x: 0, y: 20)
            videoNode.size = CGSize(width: 200, height: 200)
            videoNode.play()
            
            let clipNode = SKSpriteNode(imageNamed: "clip")
            clipNode.size = CGSize(width: 200, height: 200)
            clipNode.position = position + CGPoint(x: 0, y: 20)
            clipNode.zPosition = 100
            
            var button = SKShapeNode(rect: CGRect(x: position.x - 100, y: position.y - 150, width: 200, height: 50), cornerRadius: 10)
            button.lineWidth = 0
            button.name = "button\(names[i])"
            
            var buttonText = SKLabelNode(fontNamed: "Arial")
            buttonText.text = "Play"
            buttonText.name = "button\(names[i])"
            buttonText.position = position + CGPoint(x: 0, y: -135)
            buttonText.zPosition = 100
            buttonText.fontSize = 25
            buttonText.fontColor = .black
            
            var titleText = SKLabelNode(fontNamed: "Arial")
            titleText.text = names[i]
            titleText.position = position + CGPoint(x: 0, y: 140)
            titleText.zPosition = 100
            titleText.fontSize = 40
            titleText.fontColor = .black
            
            
            button.fillColor = UIColor(Color.blue)
            scene?.addChild(stage)
            scene?.addChild(videoNode)
            scene?.addChild(button)
            scene?.addChild(buttonText)
            scene?.addChild(titleText)
            scene?.addChild(clipNode)
        }
        if !UITraitCollection.isDarkMode {
            scene?.backgroundColor = .white
        }
    }
    
    @objc func reachEnd(notification: NSNotification) {
        let avPlayerItem = notification.object as? AVPlayerItem
        avPlayerItem?.seek(to: CMTime.zero)
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first as UITouch? {
            let location = touch.location(in: self)
            if ((self.atPoint(location).name?.hasPrefix("button")) != nil) {
                let transition = SKTransition.fade(withDuration: 2.0)
                let stage = self.atPoint(location).name!.suffix(self.atPoint(location).name!.count - 6)
                if stage == "Traditional" {
                    self.scene?.view?.presentScene(PlayScene(screen: screen, mine: ohajiki, level: 4), transition: transition)
                } else if stage == "Original 1" {
                    self.scene?.view?.presentScene(PlayScene(screen: screen, mine: ohajiki, level: 1), transition: transition)
                } else if stage == "Original 2" {
                    self.scene?.view?.presentScene(PlayScene(screen: screen, mine: ohajiki, level: 5), transition: transition)
                }
            }
        }
    }
    func createPlayer(from mov: String) -> AVPlayer {
        let url = NSURL.fileURL(withPath: Bundle.main.path(forResource: mov, ofType: "mov")!)
        let asset = AVAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)
        let avPlayer = AVPlayer(playerItem: playerItem)
        avPlayer.actionAtItemEnd = AVPlayer.ActionAtItemEnd.none;
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.reachEnd),
                                               name: NSNotification.Name("AVPlayerItemDidPlayToEndTimeNotification"),
                                               object: avPlayer.currentItem)
        return avPlayer
    }
}

