import SwiftUI
import SpriteKit
class PlayScene: SKScene, SKPhysicsContactDelegate {
    var myOhajiki: SKSpriteNode = SKSpriteNode()
    public init(screen: CGSize, mine: Ohajiki, level: Int) {
        super.init(size: screen)
        self.screen = screen
        self.mine = mine
        self.x = screen.width
        self.y = screen.height
        self.level = level
        switch level {
        case 1:
            self.stage = self.stage1
            self.points = self.stage1Point
            myOhajikiPoint = CGPoint(x: x/2, y: y/2 - 200)
            goalPosition = CGPoint(x: x/2, y: y - 100)
        case 2:
            self.stage = self.stage2
            self.points = self.stage2Point
            myOhajikiPoint = CGPoint(x: x/2, y: y/2 - 200)
            goalPosition = CGPoint(x: x/2, y: y - 100)
        case 3:
            self.stage = self.stage3
            self.points = self.stage3Point
            myOhajikiPoint = CGPoint(x: x/2 - 300, y: y/2 + 300)
            goalPosition = CGPoint(x: x/2 + 200, y: y/2 + 250)
        case 4:
            myOhajikiPoint = CGPoint(x: x/2, y: y/2)
        case 5:
            myOhajikiPoint = CGPoint(x: x/2, y: y/2)
        case 6: break
        default:
            break
        }
    }
    var x: CGFloat = 0
    var y: CGFloat = 0
    let ohajikiBit: UInt32 = 0b0011
    let lineBit: UInt32 = 0b1000
    let goalBit: UInt32 = 0b0100
    let sceneBit: UInt32 = 0b1111
    var moveLabel = SKLabelNode(text: "MoveCount 0")
    var coins = 0
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    var moves = 0
    var life = 5
    var hearts: [SKSpriteNode] = [SKSpriteNode(), SKSpriteNode(), SKSpriteNode(), SKSpriteNode(), SKSpriteNode()]
    func updateLife(to: Int) {
        life = to
        var array: [String] = []
        switch to {
        case 1:
            array = arrayHeart([false, false, false, false, true])
        case 2:
            array = arrayHeart([false, false, false, true, true])
        case 3:
            array = arrayHeart([false, false, true, true, true])
        case 4:
            array = arrayHeart([false, true, true, true, true])
        case 5:
            array = arrayHeart([true, true, true, true, true])
        case 0:
            array = arrayHeart([false, false, false, false, false])
        default:
            break
        }
        for (i, image) in array.enumerated() {
            hearts[i] = SKSpriteNode(imageNamed: image)
            hearts[i].position = CGPoint(x: x - 40 - CGFloat(40 * i), y: y - 40)
            hearts[i].size = CGSize(width: 30, height: 30)
            hearts[i].zPosition = 100
            scene?.addChild(hearts[i])
        }
    }
    func arrayHeart(_ array: [Bool]) -> [String] {
        var life: [String] = []
        for i in (0..<5) {
            let new = array[i] ? "redHeart" : "grayheart"
            life.append(new)
        }
        return life
    }
    var screen = CGSize()
    var mine = Ohajiki(color: .blue, inside: .one)
    var stage1: [[SKSpriteNode]] = [[SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki")]]
    var stage2: [[SKSpriteNode]] = [[SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki")], [SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki")]]
    var stage3: [[SKSpriteNode]] = [[SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki")], [SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki")], [SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki")]]
    var stage4: [SKSpriteNode] = [SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki"), SKSpriteNode(imageNamed: "ohajiki")]
    var stage3Point: [[CGPoint]] {
        return [[CGPoint(x: x / 2 - 200, y: y / 2 + 250), CGPoint(x: x / 2 - 200, y: y / 2 + 50)], [CGPoint(x: x / 2 - 150, y: y / 2 - 200), CGPoint(x: x / 2 + 50, y: y / 2 - 200)], [CGPoint(x: x / 2 + 100, y: y / 2 + 100), CGPoint(x: x / 2 + 300, y: y / 2 + 100)]]
    }
    var stage2Point: [[CGPoint]] {
        return [[CGPoint(x: x / 2 - 180, y: y / 2 - 180), CGPoint(x: x / 2 - 50, y: y / 2 - 50)], [CGPoint(x: x / 2 - 180, y: y / 2 + 180), CGPoint(x: x / 2 - 50, y: y / 2 + 50)]]
    }
    var stage1Point: [[CGPoint]] {
        return [[CGPoint(x: x / 2 - 80, y: y / 2 + 100), CGPoint(x: x / 2 + 80, y: y / 2 + 100)]]
    }
    var border: [CGPoint] {
        return [CGPoint(x: x / 2 - 250, y: y / 2 - 100), CGPoint(x: x / 2 - 250, y: y / 2 + 100)]
    }
    var goalPosition: CGPoint = CGPoint()
    var lines: [SKShapeNode] = []
    var stage: [[SKSpriteNode]] = []
    var points: [[CGPoint]] = []
    var myOhajikiPoint = CGPoint()
    var level = 1
    var coinLabel = SKLabelNode(text: "00")
    var coin = 0
    var startTime = Date()
    var timeLabel = SKLabelNode(fontNamed: "Arial")
    override func didMove(to view: SKView) {
        backNode.size = CGSize(width: 60, height: 100)
        backNode.alpha = 0
        self.addChild(backNode)
        if level == 2 {
            let path = CGMutablePath()
            path.move(to: border[0])
            path.addLine(to: border[1])
            let board = SKShapeNode(path: path)
            board.strokeColor = UIColor.init(red: 50, green: 50, blue: 200, alpha: 1)
            board.lineWidth = 20
            board.physicsBody = SKPhysicsBody(edgeFrom: border[0], to: border[1])
            board.physicsBody?.categoryBitMask = 0b01010001
            board.physicsBody?.restitution = 1.0
            scene?.addChild(board)
        } else if level == 3 {
            let fieldNode = SKFieldNode.linearGravityField(withVector: vector_float3(0.0,-7,0))
            fieldNode.categoryBitMask = 0b00000010
            fieldNode.position = CGPoint(x: x / 2 - 50, y: y / 2)
            fieldNode.falloff = 1.0
            let arrow = SKSpriteNode(imageNamed: "arrow")
            arrow.size = CGSize(width: 150, height: 300)
            arrow.position = CGPoint(x: x / 2 - 50, y: y / 2)
            arrow.addChild(fieldNode)
            self.addChild(arrow)
            let bound = SKSpriteNode(color: .blue, size: CGSize(width: 200, height: 1))
            bound.position = CGPoint(x: x - 50, y: 1)
            bound.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 200, height: 1))
            bound.physicsBody?.categoryBitMask = 0b0010
            bound.physicsBody?.isDynamic = false
            bound.physicsBody?.restitution = 6.0
            self.addChild(bound)
            let bane = SKSpriteNode(imageNamed: "arrowB")
            bane.size = CGSize(width: 100, height: 200)
            bane.position = CGPoint(x: x - 100, y: 100)
            self.addChild(bane)
        } else if level == 4 {
            for (index, ohajiki) in stage4.enumerated() {
                ohajiki.size = CGSize(width: 50, height: 50)
                ohajiki.position = randomFromSize(size: screen)
                ohajiki.name = "default\(index)"
                ohajiki.physicsBody = SKPhysicsBody(circleOfRadius: 25)
                ohajiki.physicsBody?.linearDamping = 2.0
                ohajiki.physicsBody?.categoryBitMask = 0b00110011
                ohajiki.physicsBody?.collisionBitMask = 0b00000011
                self.addChild(ohajiki)
                print(index)
            }
            self.physicsBody?.restitution = 0.0
            timeLabel.text = "Time: 0m00s00"
            timeLabel.position = CGPoint(x: x - 100, y: y - 40)
            timeLabel.fontSize = 30
            timeLabel.fontColor = UITraitCollection.isDarkMode ? .white : .black
            self.addChild(timeLabel)
            startTime = Date()
        } else if level == 5 {
            for (index, ohajiki) in stage4.enumerated() {
                ohajiki.size = CGSize(width: 50, height: 50)
                ohajiki.position = randomFromSize(size: screen)
                ohajiki.name = "meColor\(index % 7)"
                ohajiki.physicsBody = SKPhysicsBody(circleOfRadius: 25)
                ohajiki.physicsBody?.linearDamping = 2.0
                ohajiki.physicsBody?.categoryBitMask = 0b00110011
                ohajiki.physicsBody?.collisionBitMask = 0b00000011
                ohajiki.physicsBody?.contactTestBitMask = 0b00110011
                let choices: [Color] = [.blue, .red, .green, .yellow, .orange, .pink, .purple]
                ohajiki.texture = SKTexture(image: #imageLiteral(resourceName: "ohajikiBack.png").composite(image: Inside.fill.image.tint(with: choices[index % 7])!)!.composite(image: #imageLiteral(resourceName: "ohajikiShadow.png"))!.composite(image: #imageLiteral(resourceName: "light.png"))!)
                self.addChild(ohajiki)
            }
            timeLabel.text = "Time: 0m00s00"
            timeLabel.position = CGPoint(x: x - 100, y: y - 40)
            timeLabel.fontSize = 30
            timeLabel.fontColor = UITraitCollection.isDarkMode ? .white : .black
            self.addChild(timeLabel)
            startTime = Date()
        } else if level == 6 {
            let wwdc: [String] = ["W", "W2", "D", "C"]
            for i in (0...3) {
                let goalPoint = SKSpriteNode(imageNamed: "goal")
                goalPoint.size = CGSize(width: 80, height: 80)
                goalPoint.position = CGPoint(x: x / 5 * (CGFloat(i) + 1), y: y / 2 + 100)
                goalPoint.physicsBody = SKPhysicsBody(circleOfRadius: 40)
                goalPoint.physicsBody?.categoryBitMask = goalBit
                goalPoint.physicsBody?.collisionBitMask = goalBit
                goalPoint.physicsBody?.affectedByGravity = false
                goalPoint.zPosition = -100
                scene?.addChild(goalPoint)
                let ohajikia = SKSpriteNode(imageNamed: wwdc[i])
                ohajikia.size = CGSize(width: 50, height: 50)
                ohajikia.position = CGPoint(x: x / 5 * (CGFloat(i) + 1), y: y / 2 - 100)
                ohajikia.name = "meWWDC"
                ohajikia.physicsBody = SKPhysicsBody(circleOfRadius: 25)
                ohajikia.physicsBody?.linearDamping = 2.0
                ohajikia.physicsBody?.categoryBitMask = 0b00110011
                ohajikia.physicsBody?.collisionBitMask = 0b00000011
                ohajikia.physicsBody?.contactTestBitMask = goalBit
                self.addChild(ohajikia)
                let label = SKLabelNode(fontNamed: "Arial")
                label.fontSize = 40
                label.position = CGPoint(x: x / 2, y: y - 200)
                label.text = "Thank you for playing!"
                scene?.addChild(label)
            }
        }
        if level != 4 && level != 5 && level != 6 {
            for (i, pair) in stage.enumerated() {
                let path = CGMutablePath()
                path.move(to: points[i][0] + CGPoint(x: 0, y: 0))
                path.addLine(to: points[i][1] + CGPoint(x: 0, y: 0))
                let line = SKShapeNode(path: path)
                line.strokeColor = .orange
                line.lineWidth = 10
                line.physicsBody = SKPhysicsBody(edgeFrom: points[i][0], to: points[i][1])
                line.physicsBody?.categoryBitMask = lineBit
                line.physicsBody?.collisionBitMask = 0b00001000
                lines.append(line)
                scene?.addChild(lines[i])
                for (ai, card) in pair.enumerated() {
                    card.position = points[i][ai]
                    card.size = CGSize(width: 50, height: 50)
                    card.physicsBody = SKPhysicsBody(circleOfRadius: 25)
                    card.physicsBody?.categoryBitMask = 0b00000001
                    card.physicsBody?.collisionBitMask = 0b00000001
                    card.physicsBody?.fieldBitMask = 0b00000000
                    card.name = ai == 0 ? "move\(i)" : "add\(i)"
                    let gravityNode = SKFieldNode.radialGravityField()
                    gravityNode.categoryBitMask = 0b00000010
                    gravityNode.strength = 0.5
                    self.addChild(card)
                }
            }
            updateLife(to: 5)
            let goalPoint = SKSpriteNode(imageNamed: "goal")
            goalPoint.size = CGSize(width: 80, height: 80)
            goalPoint.position = goalPosition
            goalPoint.physicsBody = SKPhysicsBody(circleOfRadius: 40)
            goalPoint.physicsBody?.categoryBitMask = goalBit
            goalPoint.physicsBody?.collisionBitMask = goalBit
            goalPoint.physicsBody?.affectedByGravity = false
            goalPoint.physicsBody?.fieldBitMask = 0b00000000
            goalPoint.zPosition = -100
            scene?.addChild(goalPoint)
            
            moveLabel.fontSize = 30
            moveLabel.fontName = "Arial"
            moveLabel.position = CGPoint(x: 230, y: y - 50)
            moveLabel.zPosition = 100
            scene?.addChild(moveLabel)
            self.physicsBody?.restitution = 1.0
        }
        if level != 4 && level != 5 && level != 6 {
            let coinImage = SKSpriteNode(imageNamed: "coin")
            coinImage.size = CGSize(width: 30, height: 30)
            coinImage.position = CGPoint(x: 50, y: y - 40)
            coinImage.zPosition = 100
            scene?.addChild(coinImage)
            
            coinLabel.fontSize = 30
            coinLabel.fontName = "Arial"
            coinLabel.position = CGPoint(x: 90, y: y - 50)
            coinLabel.zPosition = 100
            scene?.addChild(coinLabel)
        }
        if level != 5 && level != 6 {
            myOhajiki = SKSpriteNode(texture: SKTexture(image: mine.image))
            myOhajiki.size = CGSize(width: 50, height: 50)
            self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
            myOhajiki.physicsBody = SKPhysicsBody(circleOfRadius: 25)
            myOhajiki.position = myOhajikiPoint
            myOhajiki.physicsBody?.categoryBitMask = ohajikiBit
            myOhajiki.physicsBody?.linearDamping = 1.0
            myOhajiki.physicsBody?.contactTestBitMask = lineBit | 0b00000011 | goalBit
            myOhajiki.physicsBody?.collisionBitMask = 0b00000011
            myOhajiki.name = "me"
            self.addChild(myOhajiki)
        }
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: CGRect(x:0, y:0, width: x, height: y))
        self.size = CGSize(width: x, height: y)
        self.physicsBody?.categoryBitMask = 0b1111
        self.scaleMode = .aspectFit
        self.physicsWorld.gravity = CGVector(dx:0.0, dy:0.0)
        self.physicsWorld.contactDelegate = self
        if !UITraitCollection.isDarkMode {
            self.backgroundColor = .white
            moveLabel.fontColor = .black
            coinLabel.fontColor = .black
        }
    }
    var touchBegan = CGPoint()
    var isActive = false
    var isGameOver = false
    func didBegin(_ contact: SKPhysicsContact) {
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        print(contact.bodyA.categoryBitMask, contact.bodyB.categoryBitMask)
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        } else {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        if (contact.bodyA.categoryBitMask == 0b0001) {
            if (level != 4 && level != 5) {
                updateLife(to: life - 1)
            }
        } else if (contact.bodyA.categoryBitMask == goalBit) {
            contact.bodyB.node?.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
            let action = SKAction.move(to: contact.bodyA.node!.position, duration: 0.1)
            contact.bodyB.node?.run(action)
            myOhajiki.physicsBody?.fieldBitMask = 0
            print("goal")
            if level != 6 {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [self] in
                    let dialog = CustomDialog(scene: self, frame:CGRect(x: 0, y: 0, width: x - 100, height: y - 200), moves: self.moves, coin: coin, life: self.life, level: level, mine: mine)
                    self.view!.addSubview(dialog)
                }
            }
            
        } else if (contact.bodyA.categoryBitMask == lineBit) {
            if contact.bodyA.node?.alpha != 0 {
                contact.bodyA.node?.alpha = 0
                coin += 1
                coinLabel.text = String("0\(coin)".suffix(2))
            }
            if level == 4 {
                self.childNode(withName: "add0")?.removeFromParent()
                self.childNode(withName: "move0")?.removeFromParent()
                self.childNode(withName: "line0")?.removeFromParent()
                if stageCount == 6 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [self] in
                        let timeInterval = Date().timeIntervalSince(startTime)
                        let time = Int(timeInterval)
                        let m = time / 60 % 60
                        let s = time % 60
                        let ms = Int(timeInterval * 100) % 100
                        let string = String(format: "%dm%ds%dms", m, s, ms)
                        timeLabel.text = string
                        let window = BacktoChose(scene: self, frame: CGRect(x: 0, y: 0, width: x - 100, height: y - 200), mine: mine, screen: screen, time: timeInterval, isTra: true)
                        self.view!.addSubview(window)
                    }
                }
                lines = []
                selectedOne = SKSpriteNode()
                selectedTwo = SKSpriteNode()
                oneSelect = false
                twoSelect = false
                stageCount += 1
            }
        } else if contact.bodyA.categoryBitMask == 0b00110011 && contact.bodyB.categoryBitMask == 0b00110011 {
            if contact.bodyA.node?.name == contact.bodyB.node?.name {
                let fadeAction = SKAction.fadeOut(withDuration: 1)
                contact.bodyA.node?.run(fadeAction)
                contact.bodyB.node?.run(fadeAction)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [self] in
                    contact.bodyA.node?.removeFromParent()
                    contact.bodyB.node?.removeFromParent()
                    var finished = false
                    finished = (self.childNode(withName: "meColor0") == nil) && (self.childNode(withName: "meColor2") == nil) && (self.childNode(withName: "meColor3") == nil) && (self.childNode(withName: "meColor4") == nil) && (self.childNode(withName: "meColor5") == nil) && (self.childNode(withName: "meColor6") == nil)
                    if finished {
                        let timeInterval = Date().timeIntervalSince(startTime)
                        let time = Int(timeInterval)
                        let m = time / 60 % 60
                        let s = time % 60
                        let ms = Int(timeInterval * 100) % 100
                        let string = String(format: "%dm%ds%d", m, s, ms)
                        timeLabel.text = string 
                        let window = BacktoChose(scene: self, frame: CGRect(x: 0, y: 0, width: x - 100, height: y - 200), mine: mine, screen: screen, time: timeInterval, isTra: false)
                        self.view!.addSubview(window)
                    }
                }
                stageCount += 1
            }
        }
        print(contact.bodyA.categoryBitMask, contact.bodyB.categoryBitMask)
    }
    var windowPoped = false
    var stageCount = 0
    var isSuccess = false
    var selectedOne = SKSpriteNode()
    var oneSelect = false
    var twoSelect = false
    var oneName = ""
    var twoName = ""
    var selectedTwo = SKSpriteNode()
    var controllNode = SKSpriteNode()
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let location = touches.first!.location(in: self)
        isActive = ((self.nodes(at: location).first?.name?.hasPrefix("me")) != nil) ? self.nodes(at: location).first!.name!.hasPrefix("me") : false
        print(isActive)
        if isActive {
            controllNode = self.nodes(at: location).first as! SKSpriteNode
            controllNode.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
        } else if ((self.nodes(at: location).first?.name?.hasPrefix("default") != nil) ? self.nodes(at: location).first!.name!.hasPrefix("default") : false) {
            if lines.count == 0 {
                if !oneSelect {
                    selectedOne = self.childNode(withName: (self.nodes(at: location).last?.name)!) as! SKSpriteNode
                    selectedOne.texture = SKTexture(image: #imageLiteral(resourceName: "ohajiki.png").composite(image: #imageLiteral(resourceName: "highlighted.png"))!)
                    oneName = selectedOne.name!
                    selectedOne.name = "move0"
                    oneSelect = true
                    if reChoice {
                        let path = CGMutablePath()
                        path.move(to: selectedOne.position)
                        path.addLine(to: selectedTwo.position)
                        let line = SKShapeNode(path: path)
                        line.strokeColor = .orange
                        line.lineWidth = 10
                        line.physicsBody = SKPhysicsBody(edgeFrom: selectedOne.position, to: selectedTwo.position)
                        line.physicsBody?.categoryBitMask = lineBit
                        line.physicsBody?.collisionBitMask = 0b00001000
                        line.zPosition = -10
                        lines.append(line)
                        scene?.addChild(lines[0])
                        reChoice = false
                    }
                } else if !twoSelect {
                    selectedTwo = self.childNode(withName: (self.nodes(at: location).last?.name)!) as! SKSpriteNode
                    selectedTwo.texture = SKTexture(image: #imageLiteral(resourceName: "ohajiki.png").composite(image: #imageLiteral(resourceName: "highlighted.png"))!)
                    twoName = selectedTwo.name!
                    selectedTwo.name = "add0"
                    let path = CGMutablePath()
                    path.move(to: selectedOne.position)
                    path.addLine(to: selectedTwo.position)
                    let line = SKShapeNode(path: path)
                    line.strokeColor = .orange
                    line.lineWidth = 10
                    line.physicsBody = SKPhysicsBody(edgeFrom: selectedOne.position, to: selectedTwo.position)
                    line.physicsBody?.categoryBitMask = lineBit
                    line.physicsBody?.collisionBitMask = 0b00001000
                    line.zPosition = -10
                    lines.append(line)
                    scene?.addChild(lines[0])
                    twoSelect = true
                }
            }
        } else if (((self.nodes(at: location).first?.name?.hasPrefix("move")) != nil) ? (self.nodes(at: location).first!.name! == "move0") : false) || (((self.nodes(at: location).first?.name?.hasPrefix("add")) != nil) ? (self.nodes(at: location).first!.name! == "add0") : false) {
            print("canceling")
            var select = self.childNode(withName: (self.nodes(at: location).first?.name) as! String) as? SKSpriteNode != nil ? self.childNode(withName: (self.nodes(at: location).first?.name)!) as! SKSpriteNode : SKSpriteNode()
                if select == selectedOne {
                    lines = []
                    self.childNode(withName: "line0")?.removeFromParent()
                    select.texture = SKTexture(image: #imageLiteral(resourceName: "ohajiki.png"))
                    select.name = oneName
                    oneSelect = false
                    if (self.childNode(withName: "move0") != nil || self.childNode(withName: "add0") != nil) {
                        reChoice = true
                        print("calcel12")
                    }
                    print("calcel11")
                } else if select == selectedTwo {
                    lines = []
                    self.childNode(withName: "line0")?.removeFromParent()
                    select.texture = SKTexture(image: #imageLiteral(resourceName: "ohajiki.png"))
                    select.name = twoName
                    twoSelect = false
                    print("calcel2")
            }
        }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let action = SKAction()
        let location = touches.first!.location(in: self)
        if isActive {
            controllNode.run(action,completion: {
                self.controllNode.physicsBody?.velocity = CGVector(dx: ((self.controllNode.position.x) - location.x)*3, dy: ((self.controllNode.position.y) - location.y)*3 )
                self.touchBegan = CGPoint(x: 0, y: 0)
            })
        }
        moves += 1
        moveLabel.text = "MoveCount \(moves)"
        backNode.alpha = 0
        ok = false
    }
    var s = UIColor()
    var reChoice = false
    var isStopped = CGPoint()
    var backNode = SKSpriteNode(imageNamed: "back")
    var ok = false
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isActive {
            if ok {
                backNode.alpha = 1
            }
            backNode.position = controllNode.position + CGPoint(x: 0, y: -20)
            let angle = anglePoint(point1: touches.first!.location(in: self), point2: backNode.position)
            let far = farPoint(point1: touches.first!.location(in: self), point2: backNode.position)
            let act = SKAction.rotate(toAngle: angle, duration: 0)
            let act2 = SKAction.scale(to: far / 80, duration: 0)
            let actionAll = SKAction.sequence([act,act2])
            backNode.run(actionAll)
            ok = true
        }
    }
    override func update(_ currentTime: TimeInterval) {
        if (level == 4 || level == 5) {
            let timeInterval = Date().timeIntervalSince(startTime)
            let time = Int(timeInterval)
            let m = time / 60 % 60
            let s = time % 60
            let ms = Int(timeInterval * 100) % 100
            let string = String(format: "%dm%ds%d", m, s, ms)
            timeLabel.text = string
        }
        for (i, line) in lines.enumerated() {
            let path = CGMutablePath()
            let add = self.childNode(withName: "add\(i)")
            let move = self.childNode(withName: "move\(i)")
                
            path.move(to: CGPoint(x: (add?.position.x)!, y: (add?.position.y)!))
            path.addLine(to: CGPoint(x: (move?.position.x)!, y: (move?.position.y)!))
                
            line.path = path
            line.name = "line\(i)"
            line.physicsBody = SKPhysicsBody(edgeFrom: CGPoint(x: (add?.position.x)!, y: (add?.position.y)!), to: CGPoint(x: (move?.position.x)!, y: (move?.position.y)!))
            line.physicsBody?.categoryBitMask = lineBit
            line.physicsBody?.collisionBitMask = 0x00000000
        }
    }
}
