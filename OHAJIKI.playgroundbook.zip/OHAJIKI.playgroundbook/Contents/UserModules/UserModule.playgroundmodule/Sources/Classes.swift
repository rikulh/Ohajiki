import SwiftUI
enum Window {
    case start, custom, play
}
enum Step {
    case shape, texture
}
enum Inside {
    case one, two, six, fill
    var text: String {
        switch self {
        case .one:
            return "One"
        case .two:
            return "Two"
        case .six:
            return "Six"
        case .fill:
            return "Fill"
        }
    }
    var image: UIImage {
        switch self {
        case .one:
            return #imageLiteral(resourceName: "one.png")
        case .two:
            return #imageLiteral(resourceName: "two.png")
        case .six:
            return #imageLiteral(resourceName: "six.png")
        case .fill:
            return #imageLiteral(resourceName: "fill.png")
        }
    }
}
struct Ohajiki {
    var color: Color
    var inside: Inside
    var image: UIImage {
        return #imageLiteral(resourceName: "ohajikiBack.png").composite(image: inside.image.tint(with: color)!)!.composite(image: #imageLiteral(resourceName: "ohajikiShadow.png"))!.composite(image: #imageLiteral(resourceName: "light.png"))!
    }
}
