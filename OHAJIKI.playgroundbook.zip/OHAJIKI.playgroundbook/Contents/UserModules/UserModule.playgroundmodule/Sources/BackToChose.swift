import UIKit
import SpriteKit
import SwiftUI

class BacktoChose: UIView {
    var backGroundView: UIView!
    var scene: SKScene!
    var screen: CGSize = CGSize()
    var mine: Ohajiki = Ohajiki(color: .blue, inside: .one)
    var score = 0.0
    var istra = false
    init(scene: SKScene, frame: CGRect, mine: Ohajiki, screen: CGSize, time: Double, isTra: Bool) {
        super.init(frame: scene.view!.bounds)
        self.screen = screen
        self.istra = isTra
        self.scene = scene
        self.scene.view!.isPaused = true
        self.scene.isUserInteractionEnabled = false
        self.mine = mine
        self.score = time
        self.layer.zPosition = 10
        self.backGroundView = UIView(frame: scene.view!.bounds)
        self.backGroundView.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.3)
        self.backGroundView.layer.position = scene.view!.center
        self.addSubview(backGroundView)
        
        let board = UIView(frame: frame)
        board.backgroundColor = UIColor.white
        board.layer.position = backGroundView.center
        board.layer.masksToBounds = true
        board.layer.cornerRadius = 10.0
        board.layer.borderColor = UIColor.black.cgColor
        self.addSubview(board)
        
        let textView = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 50))
        
        textView.textAlignment = NSTextAlignment.center
        textView.layer.position = CGPoint(x: backGroundView.frame.width / 2, y: 220)
        textView.backgroundColor = UIColor.clear
        textView.textColor = UIColor.black
        textView.font = UIFont(name: "Helvetica", size: 50)
        self.addSubview(textView)
        
        let first = UIView(frame: CGRect(x: (backGroundView.frame.width - board.frame.width) / 2 + 40, y: backGroundView.frame.height / 2 - 100, width: board.frame.width - 80, height: 60))
        first.backgroundColor = UIColor(displayP3Red: 0.8, green: 0.8, blue: 0.8, alpha: 1)
        first.layer.zPosition = 7
        first.layer.shadowColor = CGColor(genericCMYKCyan: 1, magenta: 1, yellow: 1, black: 1, alpha: 1)
        first.layer.shadowRadius = 20
        first.layer.shadowOpacity = 0.5
        first.layer.masksToBounds = true
        first.layer.cornerRadius = 10
        
        let name = UILabel(frame: CGRect(x: (backGroundView.frame.width - board.frame.width) / 2 + 70, y: backGroundView.frame.height / 2 - 100, width: board.frame.width - 80, height: 60))
        name.layer.zPosition = 8
        name.textColor = .black
        name.font = name.font.withSize(40)
        
        let second = UIView(frame: CGRect(x: (backGroundView.frame.width - board.frame.width) / 2 + 50, y: backGroundView.frame.height / 2 - 50, width: board.frame.width - 100, height: 60))
        second.backgroundColor = UIColor(displayP3Red: 0.6, green: 0.6, blue: 0.6, alpha: 1)
        second.layer.zPosition = 5
        second.layer.masksToBounds = true
        second.layer.cornerRadius = 10
        
        let nameSecond = UILabel(frame: CGRect(x: (backGroundView.frame.width - board.frame.width) / 2 + 90, y: backGroundView.frame.height / 2 - 50, width: board.frame.width - 100, height: 60))
        nameSecond.layer.zPosition = 6
        nameSecond.textColor = .black
        nameSecond.font = nameSecond.font.withSize(30)
        
        let time = Int(score)
        let m = time / 60 % 60
        let s = time % 60
        let ms = Int(score * 100) % 100
        let string = String(format: "%dm%ds%dms", m, s, ms)
        if istra {
            if score < 33 {
                textView.text = "You won!"
                name.text = "1. You  \(string)"
                nameSecond.text = "2. Riku 0m33s00ms"
            } else {
                textView.text = "You lose..."
                nameSecond.text = "2. You  \(string)"
                name.text = "1. Riku 0m33s00ms"
            }
        } else {
            if score < 19.5 {
                textView.text = "You won!"
                name.text = "1. You  \(string)"
                nameSecond.text = "2. Riku 0m19s50ms"
            } else {
                textView.text = "You lose..."
                nameSecond.text = "2. You  \(string)"
                name.text = "1. Riku 0m19s50ms"
            }
        }
        
        self.addSubview(first)
        self.addSubview(second)
        self.addSubview(nameSecond)
        self.addSubview(name)
        
        let anotherButton = UIButton(frame: CGRect(x: (backGroundView.frame.width - board.frame.width) / 2 + 40, y: backGroundView.frame.height - 300, width: board.frame.width - 80, height: 60))
        anotherButton.tintColor = .black
        anotherButton.layer.cornerRadius = 10
        anotherButton.setTitleColor(.black, for: .normal)
        anotherButton.setBackgroundImage(Color.blue.image, for: .normal)
        anotherButton.titleLabel?.textAlignment = .center
        anotherButton.layer.masksToBounds = true
        anotherButton.setTitle("Select another", for: .normal)
        anotherButton.titleLabel?.font = UIFont(name: "Helvetica", size: 30)
        
        
        anotherButton.addTarget(self, action: #selector(self.anotherPageButton), for: UIControl.Event.touchUpInside)
        self.addSubview(anotherButton)
        
        let finishButton = UIButton(frame: CGRect(x: (backGroundView.frame.width - board.frame.width) / 2 + 40, y: backGroundView.frame.height - 200, width: board.frame.width - 80, height: 60))
        finishButton.tintColor = .black
        finishButton.layer.cornerRadius = 10
        finishButton.setTitleColor(.black, for: .normal)
        finishButton.setBackgroundImage(Color.blue.image, for: .normal)
        finishButton.titleLabel?.textAlignment = .center
        finishButton.layer.masksToBounds = true
        finishButton.setTitle("Finish", for: .normal)
        finishButton.titleLabel?.font = UIFont(name: "Helvetica", size: 30)
        
        finishButton.addTarget(self, action: #selector(self.finishButton), for: UIControl.Event.touchUpInside)
        self.addSubview(finishButton)
        
        if UITraitCollection.isDarkMode {
            textView.textColor = .white
            board.backgroundColor = UIColor(displayP3Red: 0.2, green: 0.2, blue: 0.2, alpha: 1)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func anotherPageButton(sender: UIButton) {
        self.removeFromSuperview()
        self.scene.view?.isPaused = false
        self.scene.isUserInteractionEnabled = true
        self.scene.view?.presentScene(ChoseScene(ohaziki: mine, screen: screen))
    }
    @objc func finishButton(sender: UIButton) {
        self.removeFromSuperview()
        self.scene.view?.isPaused = false
        self.scene.isUserInteractionEnabled = true
        self.scene.view?.presentScene(PlayScene(screen: screen, mine: mine, level: 6))
    }
    
}
