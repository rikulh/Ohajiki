import Foundation
import SwiftUI
public struct MainView: View {
    public init() {}
    @State var window: Window = .start
    @Environment(\.colorScheme) var colorScheme
    @State var ohajiki = Ohajiki(color: Color.gray, inside: .one)
    public var body: some View {
        ZStack {
            switch colorScheme {
            case .dark:
                Color.init(red: 0.125, green: 0.125, blue: 0.125)
                    .edgesIgnoringSafeArea(.all)
            case .light:
                Color.white
                    .edgesIgnoringSafeArea(.all)
            }
            switch window {
            case .start:
                VStack {
                    Spacer()
                    Image(uiImage: #imageLiteral(resourceName: "Title.png").tint(with: UITraitCollection.isDarkMode ? Color.white : Color.init(red: 0.125, green: 0.125, blue: 0.125))!)
                        .resizable()
                        .frame(width: 300, height: 66, alignment: .center)
                    Spacer()
                    Image(uiImage: #imageLiteral(resourceName: "ohajiki.png").composite(image: Inside.one.image.tint(with: .blue  )!)!.composite(image: #imageLiteral(resourceName: "light.png"))!)
                        .resizable()
                        .frame(width: 200, height: 200)
                        .cornerRadius(20)
                    Spacer()
                    Button(action: {
                        withAnimation {
                            window = .custom
                        }
                    }){
                        Text("Start")
                            .font(.largeTitle)
                            .foregroundColor(.black)
                            .padding(.all)
                            .frame(width: 250)
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    Spacer()
                }
            case .custom:
                CustomView(window: $window, ohajiki: $ohajiki)
            case .play:
                PlayView(ohajiki: $ohajiki)
            }
        }
    }
}

