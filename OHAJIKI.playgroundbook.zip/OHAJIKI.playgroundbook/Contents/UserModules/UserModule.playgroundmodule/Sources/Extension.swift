import SwiftUI
import SpriteKit
import AVFoundation
// Source: https://stackoverflow.com/a/34547445/7897036
extension UIImage {
    func tint(with fillColor: Color) -> UIImage? {
        let color = UIColor(fillColor)
        let image = withRenderingMode(.alwaysTemplate)
        UIGraphicsBeginImageContextWithOptions(size, false, scale)
        color.set()
        image.draw(in: CGRect(origin: .zero, size: size))
        
        guard let imageColored = UIGraphicsGetImageFromCurrentImageContext() else {
            return nil
        }
        
        UIGraphicsEndImageContext()
        return imageColored
    }
    static func filledImage(byColor color: UIColor) -> UIImage {
        let rect = CGRect(x: 0, y: 0, width: 1000, height: 1000)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()!
        context.setFillColor(color.cgColor)
        context.fill(rect)
        let image = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return image
    }
    //source: https://blue-bear.jp/kb/swift-uiimageをマスキングする/
    func masking(maskImage: UIImage) -> UIImage {
        
        let maskRef: CGImage = maskImage.cgImage!
        let mask: CGImage = CGImage(
            maskWidth: maskRef.width,
            height: maskRef.height,
            bitsPerComponent: maskRef.bitsPerComponent,
            bitsPerPixel: maskRef.bitsPerPixel,
            bytesPerRow: maskRef.bytesPerRow,
            provider: maskRef.dataProvider!,
            decode: nil,
            shouldInterpolate: false)!;
        
        let maskedImageRef: CGImage = self.cgImage!.masking(mask)!
        let maskedImage: UIImage = UIImage(cgImage: maskedImageRef, scale: self.scale, orientation: self.imageOrientation)
        
        return maskedImage
    }
    //source: https://qiita.com/tiqwab/items/846f548416f29b5ae85a
    func composite(image: UIImage) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(self.size, false, 0)
        self.draw(in: CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height))
        let rect = CGRect(x: (self.size.width - image.size.width)/2,
                              y: (self.size.height - image.size.height)/2,
                              width: image.size.width,
                              height: image.size.height)
        image.draw(in: rect)
            
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
            
        return image
        }
    func flipHorizontal() -> UIImage {
        UIGraphicsBeginImageContextWithOptions(size, false, scale)
        let imageRef = self.cgImage
        let context = UIGraphicsGetCurrentContext()
        context?.translateBy(x: size.width, y:  size.height)
        context?.scaleBy(x: -1.0, y: -1.0)
        context?.draw(imageRef!, in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        let flipHorizontalImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return flipHorizontalImage!
    } 
    
}
extension UITraitCollection {
    public static var isDarkMode: Bool {
        return current.userInterfaceStyle == .dark
    }
}
func + (left: CGPoint, right: CGPoint) -> CGPoint {
    return CGPoint(x: left.x + right.x, y: left.y + right.y)
}
func randomFromSize(size: CGSize) -> CGPoint {
    let width = size.width
    let height = size.height
    let randomX = CGFloat.random(in: (25...width-25))
    let randomY = CGFloat.random(in: (25...height-25))
    return CGPoint(x: randomX, y: randomY)
}
func anglePoint(point1: CGPoint, point2: CGPoint) -> CGFloat {
    let x = Float(point1.x - point2.x)
    let y = Float(point1.y - point2.y)
    var radian: Float = atan2f(-y, x)
    if radian < 0 {
        radian = radian + 2 * Float(M_PI)
    }
    
    return CGFloat(-1 * radian + Float(M_PI) / 2)
}
func farPoint(point1: CGPoint, point2: CGPoint) -> CGFloat {
    let x = Float(point1.x - point2.x)
    let y = Float(point1.y - point2.y)
    var far: Float = sqrt(x*x + y*y)
    return CGFloat(far)
}
extension UIColor {
    var image: UIImage {
        return UIImage.filledImage(byColor: self)
    }
}
extension Color {
    var image: UIImage {
        return UIImage.filledImage(byColor: UIColor(self))
    }
}
